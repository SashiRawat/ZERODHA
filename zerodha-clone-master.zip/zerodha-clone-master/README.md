# Zerodha-clone

Zerodha-clone: Web Application created using React.js, bootstrap and react routing.
<br>

![Home Page](./img/Zerodha.jpeg  "Zerodha Home Page")

<br>

---------------

## File Setup

+ npm install

+ npm start

###  [Live Demo](https://zerodha.netlify.app/)

